﻿public sealed class NestedSettings
{
    public string Message { get; set; } = null!;
}